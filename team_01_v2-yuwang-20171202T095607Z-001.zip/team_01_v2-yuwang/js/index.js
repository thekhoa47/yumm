$(function() {
    // console.log( "ready!" );
    for (var i = 0; i < 15; i++) {
        var drag_item = "<img src='http://via.placeholder.com/210x210' class='drag_item yum_item_ingredient col-sm-4'>";
        $(".yum_list_ingredient").append(drag_item);
    }
    
    
    

});