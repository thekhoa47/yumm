package com.example.kylenguyen.yum;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // Step 1 : Declaration
    Button sqrrButton;
    EditText inputBox1;
    TextView resultView;
    double op, result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Step 2 : Hookup step
        sqrrButton = (Button) findViewById(R.id.button);
        inputBox1 = (EditText) findViewById(R.id.editText);
        resultView = (TextView) findViewById(R.id.textView);

        //Step 3 : Do Something
        sqrrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                op = Integer.parseInt(inputBox1.getText().toString());
                result = Math.sqrt(op);
                resultView.setText(String.valueOf(result));
            }
        });

    }
}
